#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "caracteres.h"
#include "../include/traces.h" 
#include "../include/check.h" 

int main (int argc, char * argv[]){
	assert (argc>1 && argc<4); // On s'assure qu'on a 1 ou 2 arguments
	// Cas de la compression
	if (argc==2){
	char *c=NULL;
	c=caracteres(argv[1]); // récupere tous les caractères du fichier
	//codage(c); 
	 FILE *f;
	CHECK_IF(f= fopen(argv[1],"w"), NULL, "erreur fopen dans l'ouverture du fichier");
	char c;
	while((c=getchar())!=EOF){
	fputc (c,f);	
	}
	fclose(f);
	return 0;
	}
	return 0;
	/* Cas de la décompression
	if (argc==3){
	exit(1);
	}*/
	}

