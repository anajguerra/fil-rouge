#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "compression.h"
#include "../include/traces.h" 
#include "../include/check.h" 

int main (int argc, char * argv[]){
	assert (argc>1 && argc<4); // On s'assure qu'on a 1 ou 2 arguments
	// Cas de la compression
	if (argc==3){
	compression(argv[1],argv[2]);
	return 0;
	}
	// Cas de la décompression
	if (argc==2){
	decompression(argv[1]);
	}
	}

