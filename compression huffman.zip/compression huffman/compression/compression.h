#include <stdio.h>
#include <stdlib.h>
#include "../include/traces.h" 
#include "../include/check.h" 

int nombre_car(char * fichier){
	int compte=0;
	FILE *f=NULL;
	CHECK_IF(f= fopen(fichier, "r"), NULL, "erreur fopen dans l'ouverture du fichier");
	// On compte le nombre de caractère dans le fichier
	while (fgetc(f)!=EOF){
		compte++;
		}
	fclose(f);
	return compte;
	}

char * caracteres(char * fichier){
	int i=0;
	i=nombre_car(fichier);
	FILE *f;
	CHECK_IF(f=fopen( fichier, "r"), NULL, "erreur fopen dans l'ouverture du fichier");
	char * carac;
	CHECK_IF(carac = (char *)malloc(i * sizeof (char)), NULL, "erreur fopen dans l'ouverture du fichier");
	int k=0;
	//On ajoute chaque caractère du fichier à la chaine de caractères
	while (k<i){
		carac[k]=fgetc(f); 
		k++;
		}
	return carac;
	}
	
void compression (char * fichieracompresser , char * fichierresultat){
	char *c=NULL;
	int k=0;
	int i=nombre_car(fichieracompresser); // récupère le nombre de caractères du texte dans le fichier à compresser
	c=caracteres(fichieracompresser); // récupere tous les caractères du fichier dans une chaine de caractères
	codage(c); // compresse la chaine de caractère
	FILE *f;
	CHECK_IF(f= fopen(fichierresultat,"w"), NULL, "erreur fopen dans l'ouverture du fichier"); // On ouvre le fichier resultat où on doit stocker le texte compressé
	char d;
	while(k<i){
	fputc (c[k],f);
	k++;	
	}
	fclose(f);
	}

void decompression (char * fichieradecompresser){
	char *c=NULL;
	int k=0;
	int i=nombre_car(fichieradecompresser); // récupère le nombre de caractères du texte dans le fichier à décompresser
	c=caracteres(fichieradecompresser); // récupere tous les caractères du fichier dans une chaine de caractères
	decodage(c); // décompresse la chaine de caractère
	printf("%s\n", c); 
	}

	
