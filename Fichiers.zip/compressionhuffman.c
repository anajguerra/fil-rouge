#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include "compressionhuffman.h"

#include "traces.h"
#include "check.h"


#define MAXLEN_DATA 255
#define NB_ASCII_CHAR 128

//donne le data (le tableau avec les occurences des caractères) à partir d'un texte
int * comptage(char argv[]) { //vu que il n'y a que on ne travaille qu'avec de l'ASCII, on est sûr d'avoir de récupérer un data avec les 127 dernières cases à 0
    int i = 0;
    int k = 0;
    int * occurence = NULL;
    occurence = (int * ) malloc(MAXLEN_DATA * sizeof(int));
    for (i = 0; i < MAXLEN_DATA; i++) {
        occurence[i] = 0;
    }
    while (argv[k] != '\0') {
        if ((int)argv[k] != 1) {//on ne veut pas de caractères spéciaux
            occurence[(int)argv[k]]++;
        }
        k++;
    }
    return occurence;
}

int nombre_car(char * fichier) {
    int compte = 0;
    FILE * f = NULL;
    CHECK_IF(f = fopen(fichier, "r"), NULL, "erreur fopen dans l'ouverture du fichier");
    // On compte le nombre de caractère dans le fichier
    while (fgetc(f) != EOF) {
        compte++;
    }
    fclose(f);
    return compte;
}

char * caracteres(char * fichier) {
    int i = 0;
    i = nombre_car(fichier);
    FILE * f;
    CHECK_IF(f = fopen(fichier, "r"), NULL, "erreur fopen dans l'ouverture du fichier");
    char * carac;
    CHECK_IF(carac = (char * ) malloc(i * sizeof(char)), NULL, "erreur fopen dans l'ouverture du fichier");
    int k = 0;
    //On ajoute chaque caractère du fichier à la chaine de caractères
    while (k < i) {
        carac[k] = fgetc(f);
        k++;
    }
    return carac;
}

int taillePourEcrireNombreBase10(int x)
{
    return x == 0 ? 1 : ((int)(log(x)/log(10))) +1;
}

//notre entete Huffman est de la forme : ;A29;N330;234;d1;;12;;;
char* creerEnteteHuffman (int* data)
{
    //quand on va coder l'entête, on ne sait pas quelle taille fai
    int nbOccurenceMax = 0;
    for (int i = 0; i<NB_ASCII_CHAR; i++)
        nbOccurenceMax = nbOccurenceMax < data[i] ? data[i] : nbOccurenceMax;
    int nbPlaceMax = taillePourEcrireNombreBase10(nbOccurenceMax);

    char* rep = (char*) malloc((NB_ASCII_CHAR+10)*nbPlaceMax*sizeof(char));
    rep[0] = '\0';
    strcat(rep, ";");

    for (int i = 0; i<NB_ASCII_CHAR; i++)
    {
        if (data[i] > 0)
        {
            char charDuchar = i;
            strncat(rep, &charDuchar, 1);

            int length = snprintf( NULL, 0, "%d", data[i] );
            char* str = malloc( length + 1 );
            snprintf( str, length + 1, "%d", data[i] );
            strcat(rep, str);
            free(str);

            strcat(rep, ";");
        }
    }
    strcat(rep, ";;");

    return rep;
}
T_heap* codage (char* texteACoder, char* rep) //tout simplement la fonction qui code tout. Elle prend un texte à coder, met le texte codé dans rep et revoie "l'arbre" de Huffman
{
    int* data = comptage(texteACoder);

    T_heap* dataTree = newHeap(MAXLEN_DATA);
    dataTree->tree = data;

    T_heap* huffmanTree = huffmanCodage(dataTree);

    codageFromStr(huffmanTree, texteACoder, rep);

    free(data);

    return huffmanTree;
}


void compression(char * fichieracompresser, char * fichierresultat) {
    char * c = NULL;
    int k = 0;
    int nbCharFichierInput = nombre_car(fichieracompresser); // récupère le nombre de caractères du texte dans le fichier à compresser
    c = caracteres(fichieracompresser); // récupere tous les caractères du fichier dans une chaine de caractères

    int* data = comptage(c);
    char* repEnteteHuffman = creerEnteteHuffman(data);
    char* repCodage = (char* )malloc(8*nbCharFichierInput * sizeof(char) +1);
    repCodage[0] = '\0';

    codage(c, repCodage); // compresse la chaine de caractère


    char* repFinale = malloc(strlen(repEnteteHuffman) + strlen(repCodage) + 2);
    repFinale[0] = '\0';
    strcpy(repFinale, repEnteteHuffman);  // Copy str2 to the new string
    strcat(repFinale, repCodage);
    strcat(repFinale, ";");

    free(repCodage);
    free(repEnteteHuffman);

    printf("Longueur du code binaire : %i bits\n", nbCharFichierInput);
    printf("Longueur du code de huffman : %i bits\n", strlen(repFinale));
    printf("Ratio de compression : %f\%\n", ((float)strlen(repCodage)/8)/nbCharFichierInput);


    FILE * f;
    CHECK_IF(f = fopen(fichierresultat, "w"), NULL, "erreur fopen dans l'ouverture du fichier"); // On ouvre le fichier resultat où on doit stocker le texte compressé
    while (k < strlen(repFinale)) {
        fputc(repFinale[k], f);
        k++;
    }
    free(repFinale);
    fclose(f);
}
void decompressionAvecEntete (char* fichierADecomp)
{
    //on enlève avant l'entête
    int data[MAXLEN_DATA] = {0};
    char* str0 = caracteres(fichierADecomp); // récupere tous les caractères du fichier dans une chaine de caractères
    int len0 = nombre_car(fichierADecomp);
    assert(len0 > 3);
    int i = 0;

    int tempChar;
    int tempInt;

    while(!(str0[i] == ';' && str0[i+1] == ';' && str0[i+2] == ';')) //tant qu'on est pas sortis de l'entete
    {
        i++; //on est sur le charactere ASCII
        tempChar = (int) str0[i];

        i++;
        //maintenant on est au niveau du nombre
        tempInt = 0;
        while (str0[i] != ';')
        {
            tempInt = tempInt*10 + (str0[i]-'0'); //on profite que les charactères ASCII pour les nombres sont rangés dans l'ordre
            i++;
        }
        //on est sur le ';' de fin de nombre
        data[tempChar] = tempInt;
    }
    i++;
    i++;
    i++;
    //maintenant ont est au niveau du texte à décoder
    /*
    int* data = comptage(texteACoder);

    T_heap* dataTree = newHeap(MAXLEN_DATA);
    dataTree->tree = data;

    T_heap* huffmanTree = huffmanCodage(dataTree);
    */

    T_heap* dataTree = newHeap(MAXLEN_DATA);
    dataTree->tree = data;

    T_heap* huffTree = huffmanCodage(dataTree);

    char* rep = (char*) malloc(len0*sizeof(char));
    for (int indice = 0; indice<strlen(rep); indice++)
        rep[indice] = '\0';

    decodagebitsFromBits(huffTree, str0+i, rep);

    printf("%s", rep);
    free(rep);
}
