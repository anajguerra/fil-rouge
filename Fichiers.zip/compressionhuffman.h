#ifndef _COMPRESSION_HUFFMAN_H_
#define _COMPRESSION_HUFFMAN_H_ // prévient les includes multiples

#include "elt.h"
#include"mainbis.h"

int * comptage(char argv[]);
int nombre_car(char * fichier);
char * caracteres(char * fichier);
void compression (char * fichieracompresser , char * fichierresultat);
T_heap* codage (char* texteACoder, char* rep);
char* creerEnteteHuffman (int* data);
void decompressionAvecEntete (char* fichierADecomp);

#endif
