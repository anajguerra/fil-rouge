#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
// ceil, floor : #include <math.h>


#include "traces.h"
#include "check.h"

#include "elt.h"

#include "mainbis.h"

#define HEAP_ALLOCATION_OFFSET 5




#define iPARENT(i) 			(i-1)/2
#define iLCHILD(i) 			(2*i)+1
#define iRCHILD(i) 			(2*i)+2
#define iLASTINTERNAL(n)	n/2 -1
#define isINTERNAL(i,n) 	(2*i<(n-1))
#define isLEAF(i,n) 			(2*i>=(n-1))
#define isINTREE(i,n)		(i<n)
#define isROOT(i)				(i==0)
#define nbINTERNALS(n) 		n/2
#define nbLEAVES(n) 			ceil((double)n/2)
#define VALP(pHeap, i)		pHeap->tree[i]
#define VAL(heap, i)			heap.tree[i]




// Tout est déjà écrit ! //////////////////////////////////////////////////

T_heap * newHeap(unsigned int nbMaxElt){

	T_heap * pAux;
	CHECK_IF(pAux = malloc(sizeof(T_heap)), NULL, "erreur malloc");
	CHECK_IF(pAux->tree = malloc(nbMaxElt * sizeof(T_elt)), NULL, "erreur malloc");
	pAux->nbElt = 0;
	pAux->nbMaxElt = nbMaxElt;

	return pAux;

}

void freeHeap(T_heap *p) {
	free(p->tree);
	free(p);
}


T_heap * initHeap(T_elt t[], int n) {
	T_heap *pAux = newHeap(n + HEAP_ALLOCATION_OFFSET);
	memcpy(pAux->tree, t, n * sizeof(T_elt));
	pAux->nbMaxElt = n + HEAP_ALLOCATION_OFFSET;
	pAux->nbElt = n;
	return pAux;
}

void showHeap(T_heap *p) {

	printf("Affichage du tas (nbElt : %d)\n",p->nbElt);
	showHeap_rec(p,0,0);
}

void showHeap_rec(T_heap *p, int root, int indent) {
	// affiche récursivement en mode pseudo graphique
	// ordre de récurrence  : taille du sous-arbre
	int i;

	if (! isINTREE(root,p->nbElt)) return;

	showHeap_rec(p, iRCHILD(root), indent+1);
	for(i=0;i<indent;i++) {
		printf("\t");
	}
	printf("%s(i:%d)\n",toString(VALP(p,root)), root);
	showHeap_rec(p, iLCHILD(root), indent+1);
}

void swap(T_heap *p, int i, int j) {
	T_elt aux;
	aux = p->tree[i];
	p->tree[i] = p->tree[j];
	p->tree[j] = aux;
}



void siftDownPointeur(T_heap *p, int k, T_elt *data) {

	int n = p->nbElt;
	int i;
	if (! isINTREE(k,n)) return;

	while ( ! isLEAF(k,n) ) {
		if (isINTREE(iRCHILD(k),n) && (eltCmp(data[VALP(p,iRCHILD(k))],data[VALP(p,iLCHILD(k))]) < 0)  ) i = iRCHILD(k);
		else i = iLCHILD(k);

		if (eltCmp(data[VALP(p,k)],data[VALP(p,i)]) > 0) {
			swap(p, k, i);
			k = i;
		} else break;

	}
}

void siftDown(T_heap *p, int k) {

	int n = p->nbElt;
	int i;
	if (! isINTREE(k,n)) return;

	while ( ! isLEAF(k,n) ) {
		if (isINTREE(iRCHILD(k),n) && (eltCmp(VALP(p,iRCHILD(k)),VALP(p,iLCHILD(k))) < 0)  ) i = iRCHILD(k);
		else i = iLCHILD(k);

		if (eltCmp(VALP(p,k),VALP(p,i)) > 0) {
			swap(p, k,i);
			k = i;
		} else break;

	}
}

void addEltPointeur(T_heap *p, T_elt e, T_elt *data) {
	p->tree[p->nbElt] = e;
	p->nbElt++;
	siftDownPointeur(p,p->nbElt-1, data);
}




T_elt getMin(const T_heap *p){
	return p->tree[0];
}


T_elt removeMinPointeur(T_heap *p, T_elt *data) {
	T_elt aux;
	aux = p->tree[0];
	swap(p,0,p->nbElt-1);
	p->nbElt--;
	siftDownPointeur(p,0, data);
	return aux;

}

void addElt(T_heap *p, T_elt e) {
	p->tree[p->nbElt] = e;
	p->nbElt++;
	siftDown(p,p->nbElt-1);
}


void buildHeapPointeur(T_heap *p, T_elt *data){
	int k;
	for(k=0;k < p->nbMaxElt; k++) {
		if(p-> tree[k] != 0){
		siftDownPointeur(p, k, data);
		}
	}
}

void buildHeap(T_heap *p){
	int k;
	for(k=0;k < p->nbMaxElt; k++) {
		if(p-> tree[k] != 0){
		siftDown(p, k);
		}
	}
}

void revstr(char *str1)
{
    // declare variable
    int i, len, temp;
    len = strlen(str1); // use strlen() to get the length of str string

    // use for loop to iterate the string
    for (i = 0; i < len/2; i++)
    {
        // temp variable use to temporary hold the string
        temp = str1[i];
        str1[i] = str1[len - i - 1];
        str1[len - i - 1] = temp;
    }
}




T_heap* huffmanCodage(T_heap *data) {

	int k = 0;
	int Newnoeud = 128;
	int temp;
	int nbtotchar = 0;

	T_heap* t = newHeap(256);

	for(k = 0; k < data->nbMaxElt; k++) {
		if(data-> tree[k] != 0){
		addEltPointeur(t, k, data->tree);
		nbtotchar += data->tree[k];
		}
	}
	buildHeapPointeur(t, data->tree);

	//init hufftree -256
	T_heap* Hufftree = newHeap(255);
    for (k = 0; k<Hufftree->nbMaxElt; k++) {
        Hufftree->tree[k] = -256;
    }
    Hufftree->nbElt = Hufftree->nbMaxElt;

	while(t->nbElt > 1){
		temp = removeMinPointeur(t, data->tree);
		Hufftree-> tree[temp] = -Newnoeud;
		data->tree[Newnoeud] += data->tree[temp];

		temp = removeMinPointeur(t, data->tree);
		Hufftree-> tree[temp] = +Newnoeud;
		data->tree[Newnoeud] += data->tree[temp];

		addElt(t, Newnoeud);

		Newnoeud++;
	}
	data->tree[Newnoeud] = nbtotchar; //on le fait pour la forme, vu que on ne renvoie pas data

	return Hufftree;
}


void codageFromTableAscii(T_heap *p, int c, char* rep /*malloc( 8 * sizeof(char))*/){
    //prend un char et le transforme en string de 0 et de 1 (codés avec le codage Huffman)

	while(p->tree[c]!=-256){
        if(p->tree[c] < 0){//si on est en -
			strcat(rep, "0");
			c = - (p->tree[c]);
		}
		else{
			strcat(rep, "1");
			c = p->tree[c];
		}
	}
	revstr(rep);

    //printf("%s ", rep);
}
void codageFromStr (T_heap *p, char* str0, char* rep/*malloc( 8 * sizeof(char) * str0length)*/) {
    const int str0length = strlen(str0);

    char temp[9 * sizeof(char)] = {'\0'};

    for (int i = 0; i<str0length; i++) {

        printf("%i < %i, ", i, str0length);

        codageFromTableAscii(p, (int)str0[i], temp);
        strcat(rep, temp);
        //strcat(rep, " ");
        for (int indice = 0; indice<9; indice++) {
            temp[indice] = '\0';
        }
    }
}



int getRoot(T_heap *p){
    int k = p->nbMaxElt-1;
	for(; k>0; k--){
		if(p->tree[k]!=-256){
			return k+1;
		}
	}
	if(k==0){
	    printf("grosse erreur\n");
		return -1;
	}
	printf("très très grosse erreur\n");
    return -1;
}


void decodagebitsFromBits(T_heap *p, char * input, char* rep/*malloc(strlen(input))*/) {
    //nous donne un texte normal (avec des lettres) a partir d'un hufftree et d'un texte de 0 et de 1
	int i=0;
	int k;
	int length = 0;
	int rootTemp;
	const int rootInit = getRoot(p);
	int estFeuille = 1; //<=> bool
	char tempChar;

	while (input[length] != ';') {
        length++;
	}

	//on regarde les 0/1 un par un. On descend (en bidouillant un peu) notre huffman avec rootTemp tant qu'on a pas atteind une feuille.
	//une fois une feuille atteinte, on repart de la root et on recommence.
	for(; i<length; i++){
        printf("%c", input[i]);

	    if (estFeuille) {
	        rootTemp = rootInit;
	    }
	    estFeuille = 1;
	    //on cherche (en brut force) le fils qui nous intéresse
		for(k = 0; k<p->nbElt; k++){

			if((p->tree[k] == rootTemp) && (input[i]=='1')) {
				rootTemp = k;
				estFeuille = 0; // = false
			}
			if((p->tree[k] == -rootTemp) && (input[i]=='0')){
			    rootTemp = k;
				estFeuille = 0; //= false
			}
		}
		//si on a pas trouvé le fils qu'on voulait, ça veut dire qu'on a atteind une feuille, et qu'on peut rajouter une lettre
		if (estFeuille) {
		    tempChar = rootTemp; //pour avoir un char
		    strncat(rep, &tempChar, 1);
		    i--;
		}

	}
	printf("\n \n");
}







