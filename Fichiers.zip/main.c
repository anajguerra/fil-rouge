#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <math.h>
// ceil, floor : #include <math.h>


#include "traces.h"
#include "check.h"

#include "elt.h"

#include "mainbis.h"
#include "compressionhuffman.h"

#define HEAP_ALLOCATION_OFFSET 5




/*
int main (int argc, char **argv) {
    printf("hello world!\n");

    char rep[90*8] = {'\0'};
    char rep2[90*8] = {'\0'};

    T_heap* hufftree = codage (" !#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~", rep);

    decodagebitsFromBits(hufftree, rep, rep2);

    printf("%s\n", rep2);

    //showHeap(huffmanTree);

    return 0;
}
*/

int main (int argc, char* argv[]){

	assert (argc>1 && argc<4); // On s'assure qu'on a 1 ou 2 arguments
	// Cas de la compression
	if (argc==3){
        compression(argv[1],argv[2]);
        return 0;
	}
	// Cas de la d�compression

	if (argc==2){
        decompressionAvecEntete (argv[1]);
        return 0;
	}
	return -1;
}











