#ifndef _MAINBIS_H_
#define _MAINBIS_H_

#include "elt.h"

typedef struct {
	unsigned int nbElt;
	unsigned int nbMaxElt;
	T_elt * tree;
} T_heap;



T_heap * newHeap(unsigned int nbMaxElt);
void showHeap(T_heap *p);
void freeHeap(T_heap *p);
T_heap * initHeap(T_elt t[], int n);
void swap(T_heap *p, int i, int j);
void showHeap(T_heap *p);
void showHeap_rec(T_heap *p, int root, int indent);
void siftDownPointeur(T_heap *p, int k, T_elt *data);
void siftDown(T_heap *p, int k);
void addEltPointeur(T_heap *p, T_elt e, T_elt *data);
T_elt getMin(const T_heap *p);
T_elt removeMinPointeur(T_heap *p, T_elt *data);
void addElt(T_heap *p, T_elt e);
void buildHeapPointeur(T_heap *p, T_elt *data);
void buildHeap(T_heap *p);
T_heap* huffmanCodage(T_heap *data);
void codageFromTableAscii(T_heap *p, int c, char* rep /*malloc( 8 * sizeof(char))*/);
void codageFromStr (T_heap *p, char* str0, char* rep/*malloc( 8 * sizeof(char) * str0length)*/);
void decodagebitsFromBits(T_heap *p, char* input, char* rep/*malloc(strlen(input))*/);
int getRoot(T_heap *p);

void revstr(char *str1);

#endif
