#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h> 
#include "traces.h"
#include "heapsort.h"


#define HEAP_ALLOCATION_OFFSET 5
#define iPARENT(i) 			(i-1)/2
#define iLCHILD(i) 			(2*i)+1
#define iRCHILD(i) 			(2*i)+2
#define iLASTINTERNAL(n)	n/2 -1
#define isINTERNAL(i,n) 	(2*i<(n-1))
#define isLEAF(i,n) 			(2*i>=(n-1))
#define isINTREE(i,n)		(i<n)
#define isROOT(i)				(i==0)
#define nbINTERNALS(n) 		n/2
#define nbLEAVES(n) 			ceil((double)n/2)
#define VALP(pHeap, i)		pHeap->tree[i]		
#define VAL(heap, i)			heap.tree[i]	



#ifdef MINIMIER
  #define cmp1 <
  #define cmp2 >

#endif

#ifdef MAXIMIER
  #define cmp1 >
  #define cmp2 <

#endif

void siftDown(T_heap *p, int k) { 
	int n; 
	assert(p!=NULL);
	n = p->nbElt;
	stats.nbOperations ++; 
	int i;

	stats.nbComparisons ++;
	if (!isINTREE(k,n)) return; 
		
		stats.nbComparisons ++;
		while (!isLEAF(k,n)) {
			stats.nbComparisons+=2;
			if ((isINTREE(iRCHILD(k),n) && (eltCmp(VALP(p,iRCHILD(k)),VALP(p,iLCHILD(k))) cmp1 0))) i = iRCHILD(k); 
			else i = iLCHILD(k); 
			stats.nbOperations++;
		
			stats.nbComparisons ++;
			if (eltCmp(VALP(p,k),VALP(p,i)) cmp2 0) {
				swap(p, k, i);
				k = i; 
				stats.nbOperations ++;
			} else break;  
		}
}

T_heap * newHeap(unsigned int nbMaxElt){ 
  T_heap* pAux;
	CHECK_IF(pAux = malloc(sizeof(T_heap)), NULL, "erreur malloc");
	CHECK_IF(pAux->tree = malloc(nbMaxElt * sizeof(T_elt)), NULL, "erreur malloc");
	pAux->nbElt = 0; 
	pAux->nbMaxElt = nbMaxElt; 
	return pAux; 

}

void freeHeap(T_heap *p) {
	assert(p!=NULL);
	free(p->tree);
	free(p);
}


T_heap *initHeap(T_elt t[], int n) {
	T_heap *pAux = newHeap(n + HEAP_ALLOCATION_OFFSET); 
	memcpy(pAux->tree, t, n * sizeof(T_elt)); stats.nbOperations ++;
	pAux->nbMaxElt = n + HEAP_ALLOCATION_OFFSET; stats.nbOperations ++;
	pAux->nbElt = n; stats.nbOperations ++;
	return pAux; 
}

void swap(T_heap *p, int i, int j) {
	T_elt aux; 
	assert(p!=NULL);
	aux = p->tree[i]; stats.nbOperations ++;
	p->tree[i] = p->tree[j]; stats.nbOperations ++;
	p->tree[j] = aux; stats.nbOperations ++;
}


void siftUp(T_heap *p, int k) {
	assert(p!=NULL);
	while ( !isROOT(k) && (eltCmp(VALP(p,k),VALP(p,iPARENT(k))) > 0 ) ) {
        
		swap(p,k,iPARENT(k));
		k = iPARENT(k); stats.nbOperations ++;
	}
}

void addElt(T_heap *p, T_elt e) {
	assert(p!=NULL);
	p->tree[p->nbElt] = e; 
	p->nbElt++; 
	siftUp(p,p->nbElt-1);
}


T_elt getMax(const T_heap *p){
	assert(p!=NULL);
	return p->tree[0];
}




T_elt removeMax(T_heap *p) {
	T_elt aux; 
	assert(p!=NULL);
	aux = p->tree[0]; stats.nbOperations ++;
	swap(p,0,p->nbElt-1);
	p->nbElt--; stats.nbOperations ++;
	siftDown(p,0);
	return aux; 
}


void buildHeap(T_heap * p){
	int k; 
	int n; 
	assert(p!=NULL);
	n = p->nbElt; 
	for(k=iLASTINTERNAL(n); k>=0; k--) {
		siftDown(p,k); 
    stats.nbOperations ++;
	}
}

void showHeap(T_heap *p) {
	assert(p!=NULL);
	printf("Affichage du tas (nbElt : %d)\n",p->nbElt);
	showHeap_rec(p,0,0); 
}

void showHeap_rec(T_heap *p, int root, int indent) {
	// affiche récursivement en mode pseudo graphique 
	// ordre de récurrence  : taille du sous-arbre 
	int i; 
	assert(p!=NULL);
	if (! isINTREE(root,p->nbElt)) return;  
	
	showHeap_rec(p, iRCHILD(root), indent+1);
	for(i=0;i<indent;i++) {
		printf("\t"); 
	}
	printf("%s(i:%d)\n",toString(VALP(p,root)), root);
	showHeap_rec(p, iLCHILD(root), indent+1);
}

void heapsort_aux(T_heap d) {
	
	assert((&d)!=NULL);
	buildHeap(&d);
	while((&d)->nbElt>1) {
		removeMax(&d);
	}
}

T_data heapsort(T_data d, int n){
  T_heap heap;
  heap.nbElt=n;
  heap.nbMaxElt=n;
  heap.tree=d.pElt;
  heapsort_aux(heap);
  return genData(0, heap.tree);
}

