#include <stdio.h>
#include <stdlib.h>
#include "test_utils.h"
T_data heapsort(T_data d, int n);  


// mode, label, x, checkOrder 
T_mode m[] = {
	{MODE_TAB_ORDONNE, "ordonne", 0, 1}, 
	{MODE_TAB_ALEATOIRE, "aleatoire", 0, 1}, 
	{MODE_TAB_INVERSE, "inverse", 0, 1}, 
	{MODE_EVAL_X, "x=2.0", 2.0, 0}, 
	{MODE_TAB_ORDONNE, "ordonne (x=59)", 59, 0}, 
	{MODE_TAB_ORDONNE, "hanoi", 1, 0}
};

int main(void)
{
    T_elt tab [MAX_ELT];    
    
     

	outputPath = "output"; // indiquer le chemin du répertoire où créer les fichiers
	// NB: s'il est relatif, il sera relatif au répertoire depuis lequel l'exercice est exécuté
	
	// Initialisation du générateur de nombres pseudo-aléatoires 
	srand((unsigned int)time(NULL));
	
	Test_Fn("HEAP SORT", heapsort, tab, MAX_ELT/10, m[MODE_TAB_ORDONNE] );
  Test_Fn("HEAP SORT", heapsort, tab, MAX_ELT/10, m[MODE_TAB_ALEATOIRE] );
	Test_Fn("HEAP SORT", heapsort, tab, MAX_ELT/10, m[MODE_TAB_INVERSE] );

  Test_FnV2("heap sort", heapsort, tab, 512, m[MODE_TAB_ORDONNE] );
	Test_FnV2("heap sort", heapsort, tab, 512, m[MODE_TAB_ALEATOIRE] );
	Test_FnV2("heap sort", heapsort, tab, 512, m[MODE_TAB_INVERSE] );


	
}



