#include "elt.h"
#include "test_utils.h"

#ifndef TRI
#define TRI

typedef struct {
	unsigned int nbElt;
	unsigned int nbMaxElt;
	T_elt * tree;	
} T_heap;

//#define MAXIMIER
#define MINIMIER

T_heap * newHeap(unsigned int nbMaxElt);
T_heap * initHeap(T_elt t[], int n) ;

void swap(T_heap *p, int i, int j);
void siftUp(T_heap *p, int k);
void addElt(T_heap *p, T_elt e);
void showHeap(T_heap *p);
void showHeap_rec(T_heap *p, int root, int indent); 
void siftDown(T_heap *p, int k);
T_elt getMax(const T_heap *p);
T_elt removeMax(T_heap *p);
void buildHeap(T_heap * p); 

void heapsort_aux(T_heap d);

T_data heapsort(T_data d, int n);

#endif
